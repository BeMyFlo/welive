<?php return array('dependencies' => array(), 'version' => '15ff1a53fea83f72d75a');
