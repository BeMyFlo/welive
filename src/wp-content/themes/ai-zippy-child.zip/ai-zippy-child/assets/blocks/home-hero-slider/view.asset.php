<?php return array('dependencies' => array(), 'version' => 'eb5e35827f8662641dc4');
