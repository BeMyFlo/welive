<?php return array('dependencies' => array(), 'version' => '452024a89d9a197a3a1f');
