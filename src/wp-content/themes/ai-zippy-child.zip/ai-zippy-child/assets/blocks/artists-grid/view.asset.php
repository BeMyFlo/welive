<?php return array('dependencies' => array(), 'version' => '95292addde024126b734');
