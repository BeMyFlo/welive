<?php return array('dependencies' => array(), 'version' => 'bc6c2084d9bdc6c7bda7');
